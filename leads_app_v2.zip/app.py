from flask import Flask, render_template, request, redirect, url_for, send_file, session
import pandas as pd
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta'

# Caminho do arquivo Excel
PLANILHA_PATH = 'clientes.xlsx'

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == '1234':
            session['usuario'] = username
            return redirect(url_for('menu'))
        else:
            return render_template('login.html', erro='Usuário ou senha incorretos.')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('usuario', None)
    return redirect(url_for('login'))

@app.route('/menu')
def menu():
    if 'usuario' not in session:
        return redirect(url_for('login'))
    return render_template('menu.html')

@app.route('/baixar')
def baixar():
    if 'usuario' not in session:
        return redirect(url_for('login'))
    return send_file(PLANILHA_PATH, as_attachment=True)

@app.route('/adicionar', methods=['GET', 'POST'])
def adicionar():
    if 'usuario' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        dados = {
            "Nome do responsável": request.form['responsavel'].strip().title(),
            "Número": request.form['numero'].strip(),
            "Data de contato": datetime.today().strftime("%d/%m/%Y") if request.form['data_contato'].lower() == "hoje" else request.form['data_contato'],
            "Nome do aluno": request.form['aluno'].strip().title(),
            "Idade do aluno": int(request.form['idade']),
            "Curso": request.form['curso'],
            "Data AE": request.form['data_ae'],
            "Hora planejada AE": request.form['hora_ae'],
            "Observação": request.form['observacao'].strip(),
            "Chances de fechar": request.form['chance'],
            "Ligação": request.form['ligacao']
        }
        df = pd.read_excel(PLANILHA_PATH)
        df = pd.concat([df, pd.DataFrame([dados])], ignore_index=True)
        df.to_excel(PLANILHA_PATH, index=False)
        return render_template('sucesso.html', nome=dados["Nome do responsável"])
    return render_template('adicionar.html')

if __name__ == '__main__':
    app.run(debug=True)